<#
	.SYNOPSIS
		Domain Join Storage Account
	
	.DESCRIPTION
		In case of AD_DS scenario, domain join storage account as a machine on the domain.
#>
param(
	[Parameter(Mandatory = $true)]
	[ValidateNotNullOrEmpty()]
	[string] $SubscriptionId,

	[Parameter(Mandatory = $true)]
	[ValidateNotNullOrEmpty()]
	[string] $StorageAccountName,
	
	[Parameter(Mandatory = $true)]
	[ValidateNotNullOrEmpty()]
	[string] $StorageAccountRG,

	[Parameter(Mandatory = $true)]
	[ValidateNotNullOrEmpty()]
	[string] $DomainName
)

$ErrorActionPreference = "Stop"

. (Join-Path $ScriptPath "Logger.ps1")

Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
Install-Module -Name PowershellGet -MinimumVersion 2.2.4.1 -Force
Install-Module -Name Az.Accounts -Force
Install-Module -Name Az.Storage -Force
Install-Module -Name Az.Network -Force
Install-Module -Name Az.Resources -Force
Install-Module -Name Az.ManagedServiceIdentity -Force

Write-Log "Installing AzFilesHybrid module"
$AzFilesZipLocation = Get-ChildItem -Path $PSScriptRoot -Filter "AzFilesHybrid*.zip"
Expand-Archive $AzFilesZipLocation.FullName -DestinationPath $PSScriptRoot -Force
Set-Location $PSScriptRoot
$AzFilesHybridPath = (Join-Path $PSScriptRoot "CopyToPSPath.ps1")
& $AzFilesHybridPath

# Please note: ActiveDirectory powershell module is only available on AD joined machines.
# To install it, RSAT administrative tools must be installed on the VM which will
# install the ActiveDirectory powershell module. AzFilesHybrid module takes care of
# installing the RSAT tool, ActiveDirectory powershell module.
Import-Module -Name AzFilesHybrid -Force
$ADModule = Get-Module -Name ActiveDirectory
if (-not $ADModule) {
    Request-OSFeature -WindowsClientCapability "Rsat.ActiveDirectory.DS-LDS.Tools" -WindowsServerFeature "RSAT-AD-PowerShell"
    Import-Module -Name activedirectory -Force -Verbose
}

$IsStorageAccountDomainJoined = Get-ADObject -Filter 'ObjectClass -eq "Computer"' | Where-Object {$_.Name -eq $StorageAccountName}
if ($IsStorageAccountDomainJoined) {
    Write-Log "Storage account $StorageAccountName is already domain joined."
    return
}

Write-Log "Creating AD Organizational unit 'Profiles Storage'"
Get-ADOrganizationalUnit -Filter 'Name -like "Profiles Storage"'
$OrganizationalUnit = Get-ADOrganizationalUnit -Filter 'Name -like "Profiles Storage"'
if (-not $OrganizationalUnit) {
	foreach($DCName in $DomainName.split('.')) {
		$OUPath = $OUPath + ',DC=' + $DCName
	}

	$OUPath = $OUPath.substring(1)
	New-ADOrganizationalUnit -name "Profiles Storage" -path $OUPath
}

Write-Log "Connecting to Azure..."
Connect-AzAccount -Identity -SubscriptionId $SubscriptionId

Write-Log "Domain joining storage account $StorageAccountName in Resource group $StorageAccountRG"
Join-AzStorageAccountForAuth -ResourceGroupName $StorageAccountRG -StorageAccountName $StorageAccountName -DomainAccountType 'ComputerAccount' -OrganizationalUnitName 'Profiles Storage' -OverwriteExistingADObject
Write-Log -Message "Successfully domain joined the storage account $StorageAccountName to $DomainName"

Write-Log "Updating Storage Account to support AES 256 Kerberos encryption..."
Update-AzStorageAccountAuthForAES256 -ResourceGroupName $StorageAccountRG -StorageAccountName $StorageAccountName
